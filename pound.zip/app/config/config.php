<?php
// DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');//Pm5K13dtE@
define('DB_NAME', 'pound');

// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://localhost/pound');
define('DOCROOT', $_SERVER['DOCUMENT_ROOT'].'/pound');
// Site Name
define('SITENAME', 'SITE NAME');
// App Version
define('APPVERSION', '1.0.0');

//paypal


//set it to 'false' when go live